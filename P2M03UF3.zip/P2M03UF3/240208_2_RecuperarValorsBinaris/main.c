#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE *f = fopen("..\\220202_FitxerBinariProva.bin","rb");
    if (f==NULL) {
        printf("No s'ha pogut obrir el fitxer\n");
        return 1;
    }
    // Sabem que en el fitxer binari hi ha enregistrats:
    // int, float, cadena de 4+\0, 2 double

    // Variables per recollir el qu� anem a recuperar
    int v1;
    float v2;
    char v3[255];   // Hi cabr� de sobres la cadena
    double v4[10];  // Hi cabr� de sobres els 2 double

    fread(&v1, sizeof(int), 1, f);
    fread(&v2, sizeof(float), 1, f);
    fread(v3, sizeof(char), 5, f);
    fread(v4, sizeof(double),2, f);

    printf("Valors recuperats:\n");
    printf("Int: %d\n",v1);
    printf("Float: %f\n",v2);
    printf("Cadena: %s\n",v3);
    for (int i=0; i<10; i++) {
        printf("Double: %g\n",v4[i]);
    }

    fclose(f);
    return 0;
}
