#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE *f;    // Declaraci� d'un fitxer intern
    f = fopen("valorsEnters.txt","w"); // Lliguem "f" amb fitxer extern creant-lo (w)
    if (f == NULL) {
        printf ("No s'ha pogut crear el fitxer\n");
        printf ("Acabem el programa");
        return 1;
    }
    for (int i=1; i<=100; i++)
        fprintf (f,"%d ",i);
    printf ("Hem guardat 100 enters dins el fitxer");
    fclose(f);  // Tanquem el fitxer
    return 0;
}
