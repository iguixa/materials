#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE *f;    // Declaraci� d'un fitxer intern
    // Crear un fitxer de text on posar "Hola m�n!"
    // i no fer cap tipus de lectura
    f = fopen("prova.txt","w"); // Lliguem "f" amb fitxer extern creant-lo (w)
    if (f == NULL) {
        printf ("No s'ha pogut crear el fitxer\n");
        printf ("Acabem el programa");
        return 1;
    }
    fprintf (f,"Hola m�n!");    // Enregistrem text dins el fitxer
    printf ("Hem guardat text dins el fitxer");
    fclose(f);  // Tanquem el fitxer
    return 0;
}
