#include <stdio.h>
#include <stdlib.h>

int main()
{
    int x=10;
    float y= 4.3F;
    char *s = "Hola";
    // Volem enregistrar els 3 valors en fitxer binari
    double t[] = {10.5, 4.25};

    FILE *f = fopen("..\\220202_FitxerBinariProva.bin","wb");
    if (f==NULL) {
        printf("No s'ha pogut crear el fitxer\n");
        return 1;
    }
    // Guardar la x que �s un int
    fwrite(&x,sizeof(int),1,f);
    // Guardar la y que �s un float
    fwrite(&y,sizeof(float),1,f);
    // Guardar la s que �s una cadena
    fwrite(s,sizeof(char),strlen(s)+1,f);
    // Guardar la t que �s una taula de double
    fwrite(t,sizeof(double),2,f);

    fclose(f);

    return 0;
}
