#include <stdio.h>
#include <stdlib.h>

char llegir_SN ();

int main()
{
    FILE *f = fopen ("valorsEnters.txt","a");
        // Obrim en mode afegir
    if (f==NULL) {
        printf("No s'ha pogut obrir el fitxer\n");
        printf("Avortem el programa");
        return 1;
    }
    int valor;
    printf("Vol afegir enter?");
    while (llegir_SN()=='S') {
        printf("Introdueixi valor enter: ");
        while (scanf("%d",&valor)!=1) {
            fflush(stdin);
            printf("Valor no v�lid. Introdueixi valor enter: ");
        }
        // Ha entrat valor enter
        fflush(stdin);
        fprintf(f,"%d ",valor);
        printf("Vol continuar?");
    }
    fclose(f);
    return 0;
}

char llegir_SN () {
    char aux[255];
    strcpy(aux,"");
    scanf("%s",aux);
    strupr(aux);
    while (strcmp(aux,"S")!=0 && strcmp(aux,"N")!=0) {
        printf ("Valor no v�lid. Introdueixi S o N");
        fflush(stdin);
        scanf("%s",aux);
        strupr(aux);
    }
    return aux[0];
}
