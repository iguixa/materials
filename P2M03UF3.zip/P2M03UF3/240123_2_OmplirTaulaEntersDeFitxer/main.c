#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE *f = fopen ("..\\240118_1_FitxerTextAmbEnters\\valorsEnters.txt","r");
        // Obrim en mode lectura
    if (f==NULL) {
        printf("No s'ha pogut obrir el fitxeer\n");
        printf("Avortem el programa");
        return 1;
    }

    // Ens diuen llegir com a molt 250 enters:
    int valors[250];
    int pos = 0;
    fscanf(f,"%d",&valors[pos]);
    while (!feof(f) && pos<250) {
        pos++;
        if (pos<250) {
            fscanf(f,"%d",&valors[pos]);
        }
    }
    // pos cont� la qtat de valors llegits, que com a molt ser� 250
    // Aqu� far�em el que fes falta amb la taula
    // Mostrem el contingut:
    printf("S'han recuperat %d enters:\n", pos);
    for (int i=0; i<pos; i++)
        printf("%d ",valors[i]);

    return 0;
}
