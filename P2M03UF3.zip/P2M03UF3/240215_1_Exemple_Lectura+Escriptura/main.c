#include <stdio.h>
#include <stdlib.h>

int main()
{
    int copia = system("copy /y prova_original.txt prova.txt");
    if (copia!=0) {
        printf("No s'ha pogut copiar el fitxer a gestionar. Avortem programa");
        return 1;
    }
    FILE *f = fopen("prova.txt","r+");
    if (f==NULL) {
        printf("No es pot obrir el fitxer");
        return 1;
    }
    char paraula[50];

    // El fitxer cont� m�s de 4 paraules
    // Volem llegir 4 paraules
    printf("Llegim les 4 primeres paraules:\n");
    for (int i=1; i<=4; i++) {
        fscanf(f,"%s",paraula);
        printf("%s\n",paraula);
    }

    rewind(f);  // Em posiciono a l'inici
    // Alternativament:
//    fseek(f,0,SEEK_SET);

    // Anem a escriure a l'inici

    fprintf(f,"ABRACADABRA");
    fflush(f);

    printf("Llegim les 5 paraules que venen despr�s d'ABRACADABRA:\n");
    for (int i=1; i<=5; i++) {
        fscanf(f,"%s",paraula);
        printf("%s\n",paraula);
    }

    // Anem a escriure a la mateixa posici�:
    /*
    fpos_t aux;
    fgetpos(f,&aux);    // Omple "aux" amb la posici�
    fsetpos(f,&aux);    // Es posiciona a la posici�
    */
    // Alternativament,  molt m�s f�cil
    fseek(f,0,SEEK_CUR);

    fprintf(f,"XXXX");

    //Ara volem afegir al final
    fseek(f,0,SEEK_END);
    fprintf(f,"YYYY");

    fclose(f);
    return 0;
}
