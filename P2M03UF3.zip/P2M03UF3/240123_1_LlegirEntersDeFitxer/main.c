#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE *f = fopen ("..\\240118_1_FitxerTextAmbEnters\\valorsEnters.txt","r");
        // Obrim en mode lectura
    if (f==NULL) {
        printf("No s'ha pogut obrir el fitxeer\n");
        printf("Avortem el programa");
        return 1;
    }
    int valor; // Variable per guardar-hi el valor que llegim del fitxer
    fscanf(f,"%d",&valor);  // llegir el 1r valor
    while (!feof(f)) {  // mentre no final de fitxer
        // "valor" cont� el valor llegit, que ens demanen mostrar per pantalla
        printf("%d ",valor); // tractament demanat
        fscanf(f,"%d",&valor);  // llegir el seg�ent
    }
    fclose(f);
    return 0;
}
