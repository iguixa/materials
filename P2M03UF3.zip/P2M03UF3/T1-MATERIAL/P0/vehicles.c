#include <stdio.h>
#include <stdlib.h>

#include "vehicles.h"

void llegir_vehicle_teclat(tVehicle *v) {

}

void mostrar_vehicle_pantalla(tVehicle v) {
    printf("Codi: %d\n", v.codi);
}
