#ifndef VEHICLES_H_INCLUDED
#define VEHICLES_H_INCLUDED


#define LEN_MARCA 60
#define LEN_MODEL 60

typedef struct {
   int codi;
   char marca[LEN_MARCA+1];
   char model[LEN_MODEL+1];
   int cv;
} tVehicle;

void llegir_vehicle_teclat(tVehicle *v);

void mostrar_vehicle_pantalla(tVehicle v);

void llegir_codi_vehicle(int &codi);

void llegir_vehicle_teclat_menysCodi (tVehivle *v);


#endif // VEHICLES_H_INCLUDED
