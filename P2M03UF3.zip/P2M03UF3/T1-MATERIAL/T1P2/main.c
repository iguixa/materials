#include <stdio.h>
#include <stdlib.h>

void recuperar_vehicle_fitxer_text(FILE *f, tVehicle *t) {

}

int main()
{

    preguntar_si_vol_afegir_vehicles;
    mentre SI fer
        demanar_codi_per_teclat;
        obrir_fitxer_lectura;
        llegir_vehicle_de_fitxer;
        mentre (no final i vehicle no sigui el codi cercat) {
            llegir_vehicle_de_fitxer;
        }
        si (hem_arribat_a_final_fitxer) {
            /* no trobat */
            demanar_resta_camps;
            tancar_fitxer (en lectura);
            obrir_fitxer_en_append;
            afegir_vehicle_en_el_fitxer;
        } sino {
            informem de que ja existeix un vehicle amb el codi;
            mostrar_vehicle_pantalla;
        }
        tancar_fitxer;
        vol continuar afegint vehicles?
    fimentre

}
