#include <stdio.h>
#include <stdlib.h>

void recuperar_vehicle_fitxer_text(FILE *f, tVehicle *t) {

}

int main()
{
    /* 1. Declarar fitxer i obrir-lo */

    /* 2. Ha de recuperar tots els vehicles que hi ha en el fitxer,
    invocant funci� recuperar_vehible_fitxer_text
    i mostrar-lo per pantalla invocant mostrar_vehicle_pantalla
    Aix� repetitivament fins que no quedin m�s vehicles dins el fitxer */

    /* 3. Tancar fitxer */

}
