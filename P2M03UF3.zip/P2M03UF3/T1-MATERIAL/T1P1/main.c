#include <stdio.h>
#include <stdlib.h>

#include "../P0/vehicles.h"

void afegir_vehicle_fitxer_text(FILE *f, tVehicle t) {

}


int main()
{
    tVehicle t;

    /* 1. Declarar fitxer i obrir-lo */

    /* 2. Demanar a l'usuari si vol introduir vehicles.
    En cas afirmatiu, demanar les dades invocant llegir_vehicle_teclat
    i afegir-lo dins el fitxer de text invocant afegir_vehicle_fitxer_text
    Aix� repetitivament fins que l'usuari diu que no vol afegir m�s */

    /* 3. Tancar fitxer */
}
