/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.milaifontanals.jpa;

import org.milaifontanals.biblioteca.Fitxa;
import org.milaifontanals.biblioteca.FitxaRevista;
import org.milaifontanals.biblioteca.Soci;
import java.util.Date;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import java.util.Scanner;

/**
 *
 * @author Professor
 */
public class P02_ComprovaGestioObjectes {

    public static void main(String[] args) {

        if (args.length != 1) {
            System.out.println("Un únic argument amb el nom de la Unitat de Persistència");
            System.exit(1);
        }
        String up = args[0];
        EntityManagerFactory emf = null;
        EntityManager em = null;
        try {
            em = null;
            emf = null;
            System.out.println("Intent amb " + up);
            emf = Persistence.createEntityManagerFactory(up);
            System.out.println("EntityManagerFactory creada");
            em = emf.createEntityManager();
            System.out.println();
            System.out.println("EntityManager creat");

            Soci s1 = new Soci(1, "Gotera", "Pepe", new Date(100, 0, 1), 'M');
            Soci s2 = new Soci(2, "Rodriguez", "Pepe", new Date(100, 0, 1), 'M');
            Fitxa fr = new FitxaRevista("1234567891", "Er gato", 2000, 1);
            // Fer persistent s1
            em.persist(s1);     // Més lògic fer-ho després de begin().
            // Però funciona!!!
//            em.persist(fr); // No possible per què FitxaRevista NO és Entity
            em.getTransaction().begin();
            em.flush();     // Envia les instruccions SQL a la BD, però sense commit
            System.out.println("Hem fet flush... El soci s1 ha estat enviat a la BD");
            
            Scanner sc = new Scanner (System.in);
            System.out.println("Comprovi si a la BD hi ha el soci s1 i, en cas de no ser-hi, si el pot afegir...");
            System.out.println("Quan hagi fet la comprovació, premi tecla per continuar...");
            sc.nextLine();
            
            em.getTransaction().commit();
            System.out.println("Hem fet commit. Comprovi l'estat de la inserció manual de s1 a la BD");
            
        } catch (Exception ex) {
            System.out.println("Exception: " + ex.getMessage());
            System.out.print(ex.getCause() != null ? "Caused by:" + ex.getCause().getMessage() + "\n" : "");
            System.out.println("Traça:");
            ex.printStackTrace();
        } finally {
            if (em != null) {
                if (em.getTransaction().isActive()) {
                    em.getTransaction().rollback();
                }
                em.close();
                System.out.println("EntityManager tancat");
            }
            if (emf != null) {
                emf.close();
                System.out.println("EntityManagerFactory tancada");
            }
        }
    }
}
